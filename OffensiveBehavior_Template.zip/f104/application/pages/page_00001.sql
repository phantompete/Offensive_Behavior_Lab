prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>9016125576488468
,p_default_application_id=>104
,p_default_id_offset=>12868366591002101
,p_default_owner=>'PHANTOMPETE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Data Science Application'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var myInterval; //Stores the interval variable',
'',
'function fn_click_trigger()',
'{',
'   myInterval = setInterval(fn_click, 5000); //Refresh every 5 seconds',
'   apex.item(''ANALYZE'').hide();',
'}',
'',
'function fn_click_stop()',
'{',
'    clearInterval(myInterval);',
'}',
'',
'function fn_click()',
'{',
'    // Call Ajax process to execute some PL/SQL code',
'    apex.server.process (''GetStatus'' //PL/SQL process name',
'    ,{x01: $v(''JOBRUN_RESPONSE'')}',
'    ,{ dataType : ''json''',
'    //, async : false',
'    , success : function(pData)',
'         {            ',
'             //Store the PL/SQL result in a Page item',
'             apex.item("LIFECYCLESTATE").setValue(pData.lifeState);',
'             apex.item("LIFECYCLEDETAILS").setValue(pData.lifeStatus);',
'         }',
'    }',
'    ).done( function(pData)',
'        {',
'            // Do the post processing here, next set of code post PL/SQL call',
'            if(pData.lifeState == "SUCCEEDED") {',
'                 fn_click_stop();',
'                 apex.submit(''STATUS'');',
'                 apex.item(''ANALYZE'').show();',
'            }',
'',
'            if(pData.lifeState == "FAILED") {',
'                 fn_click_stop();',
'                 apex.item(''ANALYZE'').show();',
'            }',
'        }',
'    );',
'}',
'',
'    ',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'PHANTOMPETE'
,p_last_upd_yyyymmddhh24miss=>'20230815100340'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25601529454767164)
,p_plug_name=>'Data Science Application'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured t-HeroRegion--centered'
,p_plug_template=>wwv_flow_imp.id(25392388887766878)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24703020336519909)
,p_plug_name=>'Container'
,p_parent_plug_id=>wwv_flow_imp.id(25601529454767164)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(25408182856766886)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24703456831519913)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(24703020336519909)
,p_button_name=>'Analyze'
,p_button_static_id=>'ANALYZE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(25481392372766946)
,p_button_image_alt=>'Analyze'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24703483401519914)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(24703020336519909)
,p_button_name=>'Status'
,p_button_static_id=>'STATUS'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(25481392372766946)
,p_button_image_alt=>'Status'
,p_button_redirect_url=>'javascript:fn_click_trigger();'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24703154054519910)
,p_name=>'VIDEO_URL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(24703020336519909)
,p_prompt=>'Video Url'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(25478957902766942)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24703197736519911)
,p_name=>'ALGORITHM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(24703020336519909)
,p_prompt=>'Analysis Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ALGORITHM_TYPES'
,p_lov=>'.'||wwv_flow_imp.id(25677301037076415)||'.'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(25478957902766942)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24703331940519912)
,p_name=>'PICTURE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(24703020336519909)
,p_prompt=>'Picture'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_display_when=>'ALGORITHM'
,p_display_when2=>'video_only:both'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(25478957902766942)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'.jpg'
,p_attribute_12=>'DROPZONE_INLINE'
,p_attribute_13=>'Upload Profile Picture'
,p_attribute_14=>'The image should display a selfie of a single person.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24704124866519920)
,p_name=>'JOBRUN_RESPONSE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(24703020336519909)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24704177426519921)
,p_name=>'LIFECYCLESTATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(24703020336519909)
,p_prompt=>'Lifecycle State'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(25478957902766942)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24704353940519922)
,p_name=>'LIFECYCLEDETAILS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(24703020336519909)
,p_prompt=>'Lifecycle Details'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(25478957902766942)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(24703638202519915)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'JobProcess'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(24703456831519913)
,p_internal_uid=>11835271611517814
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(24705531401519934)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GetStatus'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_params apex_exec.t_parameters;',
'    j apex_json.t_values;',
'    lifecyclestate varchar2(50);',
'    lifecyclestatus varchar2(250);',
'BEGIN',
'    apex_json.parse(j, :JOBRUN_RESPONSE);',
'    apex_exec.add_parameter( l_params, ''id'', apex_json.get_varchar2(p_path=>''id'',p0=> 3,p_values=>j) );',
'    apex_exec.add_parameter( l_params, ''jobId'',apex_json.get_varchar2(p_path=>''jobId'',p0=> 3,p_values=>j) );',
'    apex_exec.add_parameter( l_params, ''compartmentId'',apex_json.get_varchar2(p_path=>''compartmentId'',p0=> 3,p_values=>j) );',
'    apex_exec.add_parameter( l_params, ''projectId'',apex_json.get_varchar2(p_path=>''projectId'',p0=> 3,p_values=>j) );',
'',
'    apex_exec.execute_rest_source(',
'        p_static_id        => ''listjobruns'', --Get this static ID from the REST Data Source',
'        p_operation        => ''GET'',',
'        p_parameters       => l_params );',
'',
'     apex_json.parse(j, apex_exec.get_parameter_clob(l_params,''Response''));',
'     apex_json.open_object;',
'  ',
'     lifecyclestate := apex_json.get_varchar2(p_path=>''[%d].lifecycleState'',p0 => 1,p_values=>j);',
'     lifecyclestatus := apex_json.get_varchar2(p_path=>''[%d].lifecycleDetails'',p0 => 1,p_values=>j);',
'     ',
'     apex_json.write( p_name  => ''lifeState'', p_value => lifecyclestate);',
'     apex_json.write( p_name  => ''lifeStatus'', p_value => lifecyclestatus);',
'',
'     apex_json.close_object;',
'     :LIFECYCLESTATE := lifecyclestate; --Persist update of status.',
'',
'END;',
'',
'    '))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'JOBRUN_RESPONSE'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>11837164810517833
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(24703765590519916)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(24703638202519915)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UploadPictureSQL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request_url varchar(32000);',
'    l_content_length number;',
'    l_response clob;',
'    upload_failed_exception exception;',
'    l_request_object blob;',
'    l_request_filename varchar2(500);',
'    begin',
'        select blob_content, filename into l_request_object, l_request_filename from apex_application_temp_files where name = :PICTURE;',
'        l_request_url := ''https://objectstorage.eu-frankfurt-1.oraclecloud.com/n/namespace/b/bucket_name/o/folder_name /'' || apex_util.url_encode(l_request_filename);        ',
'l_response := apex_web_service.make_rest_request(',
'            p_url => l_request_url,',
'            p_http_method => ''PUT'',',
'            p_body_blob => l_request_object,',
'            p_credential_static_id => ''OCI_API'' --Update with your Web Credentials',
'        );end;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'PICTURE'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>11835398999517815
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(24703823851519917)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(24703638202519915)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'CreateJobRun'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(25657844050837734)
,p_web_src_operation_id=>wwv_flow_imp.id(25658054333837735)
,p_attribute_01=>'WEB_SOURCE'
,p_internal_uid=>11835457260517816
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(24704430609519923)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(25661119613906737)
,p_page_process_id=>wwv_flow_imp.id(24703823851519917)
,p_value_type=>'ITEM'
,p_value=>'ALGORITHM'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(24704484026519924)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(25662593221906738)
,p_page_process_id=>wwv_flow_imp.id(24703823851519917)
,p_value_type=>'STATIC'
,p_value=>'Enter your bucket name here'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(24704586479519925)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(25662075098906738)
,p_page_process_id=>wwv_flow_imp.id(24703823851519917)
,p_value_type=>'STATIC'
,p_value=>'Enter your bucket Namespace here '
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(24704674055519926)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(25659585703906737)
,p_page_process_id=>wwv_flow_imp.id(24703823851519917)
,p_value_type=>'STATIC'
,p_value=>'Enter the Data Science Compartment ID here'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(24704783438519927)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(25660580776906737)
,p_page_process_id=>wwv_flow_imp.id(24703823851519917)
,p_value_type=>'STATIC'
,p_value=>'MyNewJob'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(24704899007519928)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(25660118338906737)
,p_page_process_id=>wwv_flow_imp.id(24703823851519917)
,p_value_type=>'STATIC'
,p_value=>'Enter the Data Science Job ID here'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(24705037681519929)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(25659144036906736)
,p_page_process_id=>wwv_flow_imp.id(24703823851519917)
,p_value_type=>'STATIC'
,p_value=>'Enter the Data Science Project ID here'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(24705158429519930)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(25663609208923071)
,p_page_process_id=>wwv_flow_imp.id(24703823851519917)
,p_value_type=>'ITEM'
,p_value=>'JOBRUN_RESPONSE'
,p_ignore_output=>false
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(24705227375519931)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(25663130326906738)
,p_page_process_id=>wwv_flow_imp.id(24703823851519917)
,p_value_type=>'STATIC'
,p_value=>'&APP_USER.'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(24705320695519932)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(25661578127906738)
,p_page_process_id=>wwv_flow_imp.id(24703823851519917)
,p_value_type=>'ITEM'
,p_value=>'VIDEO_URL'
);
wwv_flow_imp.component_end;
end;
/
