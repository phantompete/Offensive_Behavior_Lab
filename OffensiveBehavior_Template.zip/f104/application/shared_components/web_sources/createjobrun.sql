prompt --application/shared_components/web_sources/createjobrun
begin
--   Manifest
--     WEB SOURCE: CreateJobRun
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>9016125576488468
,p_default_application_id=>104
,p_default_id_offset=>12868366591002101
,p_default_owner=>'PHANTOMPETE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(25657844050837734)
,p_name=>'CreateJobRun'
,p_static_id=>'createjobrun'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(25657009174837726)
,p_remote_server_id=>wwv_flow_imp.id(12788483548835622)
,p_url_path_prefix=>'/20190101'
,p_credential_id=>wwv_flow_imp.id(12876048461133303)
,p_attribute_05=>'1'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(25658054333837735)
,p_web_src_module_id=>wwv_flow_imp.id(25657844050837734)
,p_operation=>'POST'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'/jobRuns'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'    "projectId": "#projectid#",',
'    "compartmentId": "#compartmentid#",',
'    "jobId": "#jobid#",',
'    "definedTags": {},',
'    "displayName": "#displayName#",',
'    "freeformTags": {},',
'    "jobConfigurationOverrideDetails": {',
'        "jobType": "DEFAULT",',
'        "environmentVariables": {',
'            "TYPE_OF_ANALYSIS": "#ANALYSIS_TYPE#",  ',
'            "YOUTUBE_URL": "#YOUTUBE_URL#",',
'            "NAMESPACE_NAME" : "#BUCKET_NAMESPACE#",',
'            "MAIN_BUCKET_NAME": "#BUCKET_NAME#", ',
'            "SCHEMA_NAME": "#SCHEMA_NAME#"}',
'        }',
'    }',
'}'))
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(25659144036906736)
,p_web_src_module_id=>wwv_flow_imp.id(25657844050837734)
,p_web_src_operation_id=>wwv_flow_imp.id(25658054333837735)
,p_name=>'projectid'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(25659585703906737)
,p_web_src_module_id=>wwv_flow_imp.id(25657844050837734)
,p_web_src_operation_id=>wwv_flow_imp.id(25658054333837735)
,p_name=>'compartmentid'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(25660118338906737)
,p_web_src_module_id=>wwv_flow_imp.id(25657844050837734)
,p_web_src_operation_id=>wwv_flow_imp.id(25658054333837735)
,p_name=>'jobid'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(25660580776906737)
,p_web_src_module_id=>wwv_flow_imp.id(25657844050837734)
,p_web_src_operation_id=>wwv_flow_imp.id(25658054333837735)
,p_name=>'displayName'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(25661119613906737)
,p_web_src_module_id=>wwv_flow_imp.id(25657844050837734)
,p_web_src_operation_id=>wwv_flow_imp.id(25658054333837735)
,p_name=>'ANALYSIS_TYPE'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(25661578127906738)
,p_web_src_module_id=>wwv_flow_imp.id(25657844050837734)
,p_web_src_operation_id=>wwv_flow_imp.id(25658054333837735)
,p_name=>'YOUTUBE_URL'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(25662075098906738)
,p_web_src_module_id=>wwv_flow_imp.id(25657844050837734)
,p_web_src_operation_id=>wwv_flow_imp.id(25658054333837735)
,p_name=>'BUCKET_NAMESPACE'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(25662593221906738)
,p_web_src_module_id=>wwv_flow_imp.id(25657844050837734)
,p_web_src_operation_id=>wwv_flow_imp.id(25658054333837735)
,p_name=>'BUCKET_NAME'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(25663130326906738)
,p_web_src_module_id=>wwv_flow_imp.id(25657844050837734)
,p_web_src_operation_id=>wwv_flow_imp.id(25658054333837735)
,p_name=>'SCHEMA_NAME'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(25663609208923071)
,p_web_src_module_id=>wwv_flow_imp.id(25657844050837734)
,p_web_src_operation_id=>wwv_flow_imp.id(25658054333837735)
,p_name=>'Response'
,p_param_type=>'BODY'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(25663972019932812)
,p_web_src_module_id=>wwv_flow_imp.id(25657844050837734)
,p_web_src_operation_id=>wwv_flow_imp.id(25658054333837735)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp.component_end;
end;
/
