prompt --application/shared_components/user_interface/lovs/algorithm_types
begin
--   Manifest
--     ALGORITHM_TYPES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>9016125576488468
,p_default_application_id=>104
,p_default_id_offset=>12868366591002101
,p_default_owner=>'PHANTOMPETE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(25677301037076415)
,p_lov_name=>'ALGORITHM_TYPES'
,p_lov_query=>'.'||wwv_flow_imp.id(25677301037076415)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(25677568360076416)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Audio'
,p_lov_return_value=>'audio_only'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(25678031124076416)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Video'
,p_lov_return_value=>'video_only'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(25678462381076416)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Both (Audio & Video)'
,p_lov_return_value=>'both'
);
wwv_flow_imp.component_end;
end;
/
