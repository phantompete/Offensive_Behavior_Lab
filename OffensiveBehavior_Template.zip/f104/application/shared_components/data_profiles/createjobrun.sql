prompt --application/shared_components/data_profiles/createjobrun
begin
--   Manifest
--     DATA PROFILE: CreateJobRun
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>9016125576488468
,p_default_application_id=>104
,p_default_id_offset=>12868366591002101
,p_default_owner=>'PHANTOMPETE'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(25657009174837726)
,p_name=>'CreateJobRun'
,p_format=>'JSON'
,p_use_raw_json_selectors=>false
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(25657213440837730)
,p_data_profile_id=>wwv_flow_imp.id(25657009174837726)
,p_name=>'CODE'
,p_sequence=>1
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>32767
,p_has_time_zone=>false
,p_selector=>'code'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(25657558223837731)
,p_data_profile_id=>wwv_flow_imp.id(25657009174837726)
,p_name=>'MESSAGE'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>32767
,p_has_time_zone=>false
,p_selector=>'message'
);
wwv_flow_imp.component_end;
end;
/
