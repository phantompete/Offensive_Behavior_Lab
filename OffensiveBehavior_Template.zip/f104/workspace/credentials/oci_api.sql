prompt --workspace/credentials/oci_api
begin
--   Manifest
--     CREDENTIAL: OCI_API
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>9016125576488468
,p_default_application_id=>104
,p_default_id_offset=>12868366591002101
,p_default_owner=>'PHANTOMPETE'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(12876048461133303)
,p_name=>'OCI_API'
,p_static_id=>'OCI_API'
,p_authentication_type=>'OCI'
,p_namespace=>'enteryourtenancyocid'
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
