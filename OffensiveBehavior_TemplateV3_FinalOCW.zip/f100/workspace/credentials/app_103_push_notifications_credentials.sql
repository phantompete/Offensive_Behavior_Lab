prompt --workspace/credentials/app_103_push_notifications_credentials
begin
--   Manifest
--     CREDENTIAL: App 103 Push Notifications Credentials
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>7487498804536870
,p_default_application_id=>100
,p_default_id_offset=>7489314402657690
,p_default_owner=>'MLTD_USERA01'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(20275561002422916)
,p_name=>'App 103 Push Notifications Credentials'
,p_static_id=>'App_103_Push_Notifications_Credentials'
,p_authentication_type=>'KEY_PAIR'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
