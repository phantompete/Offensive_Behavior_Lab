prompt --workspace/remote_servers/datascience_eu_frankfurt_1_oci_oraclecloud_com
begin
--   Manifest
--     REMOTE SERVER: datascience-eu-frankfurt-1-oci-oraclecloud-com
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>7487498804536870
,p_default_application_id=>100
,p_default_id_offset=>7489314402657690
,p_default_owner=>'MLTD_USERA01'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(20277797951493312)
,p_name=>'datascience-eu-frankfurt-1-oci-oraclecloud-com'
,p_static_id=>'datascience_eu_frankfurt_1_oci_oraclecloud_com'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('datascience_eu_frankfurt_1_oci_oraclecloud_com'),'https://datascience.eu-frankfurt-1.oci.oraclecloud.com/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('datascience_eu_frankfurt_1_oci_oraclecloud_com'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('datascience_eu_frankfurt_1_oci_oraclecloud_com'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('datascience_eu_frankfurt_1_oci_oraclecloud_com'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('datascience_eu_frankfurt_1_oci_oraclecloud_com'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
