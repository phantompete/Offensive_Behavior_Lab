prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>7487498804536870
,p_default_application_id=>100
,p_default_id_offset=>7489314402657690
,p_default_owner=>'MLTD_USERA01'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Analysis Results'
,p_alias=>'ANALYSIS-RESULTS'
,p_page_mode=>'MODAL'
,p_step_title=>'Analysis Results'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'27'
,p_last_updated_by=>'MLTD_USERA01'
,p_last_upd_yyyymmddhh24miss=>'20230829103543'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19326708215175525)
,p_plug_name=>'Offensive Indicators'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(32832328392424535)
,p_plug_display_sequence=>40
,p_query_type=>'TABLE'
,p_query_table=>'OCW_RUN_RESULTS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_landmark_type=>'region'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(19326736977175526)
,p_region_id=>wwv_flow_imp.id(19326708215175525)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19326859867175527)
,p_chart_id=>wwv_flow_imp.id(19326736977175526)
,p_seq=>10
,p_name=>'Offensive'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select JOB_RUN_OCID,',
'       TYPE_OF_ANALYSIS,',
'       OUTPUT_IN_SCREEN,',
'       SECONDS_IN_SCREEN,',
'       TOTAL_SECONDS_VIDEO_ANALYZED,',
'       TRANSCRIPTION,',
'       KEY_PHRASES_STRING,',
'       SENTIMENT_RESULT_STRING,',
'       NEG_ASPECTS,',
'       NON_OFFENSIVE_INT,',
'       (OFFENSIVE_INT/100.00) OFFENSIVE_PCT,',
'       NON_HATE_INT,',
'       HATE_INT,',
'       (select ''Offensive'' from dual) LABEL',
'  from OCW_RUN_RESULTS',
'--where JOB_RUN_OCID = :JOBID'))
,p_ajax_items_to_submit=>'JOBID'
,p_items_value_column_name=>'OFFENSIVE_PCT'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(20543629141328493)
,p_chart_id=>wwv_flow_imp.id(19326736977175526)
,p_seq=>20
,p_name=>'Non Offensive'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select JOB_RUN_OCID,',
'       TYPE_OF_ANALYSIS,',
'       OUTPUT_IN_SCREEN,',
'       SECONDS_IN_SCREEN,',
'       TOTAL_SECONDS_VIDEO_ANALYZED,',
'       TRANSCRIPTION,',
'       KEY_PHRASES_STRING,',
'       SENTIMENT_RESULT_STRING,',
'       NEG_ASPECTS,',
'       (NON_OFFENSIVE_INT/100.00) NON_OFFENSIVE_PCT,',
'       (OFFENSIVE_INT/100.00) OFFENSIVE_PCT,',
'       NON_HATE_INT,',
'       HATE_INT,',
'       (select ''Non Offensive'' from dual) LABEL',
'  from OCW_RUN_RESULTS',
'--where JOB_RUN_OCID = :JOBID',
''))
,p_ajax_items_to_submit=>'JOBID'
,p_items_value_column_name=>'NON_OFFENSIVE_PCT'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20541358139115939)
,p_plug_name=>'Analysis Results - Type of analysis: &TYPE_OF_ANALYSIS. '
,p_region_template_options=>'#DEFAULT#:margin-top-none:margin-bottom-none:margin-left-sm:margin-right-sm'
,p_plug_template=>wwv_flow_imp.id(32830975500424534)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_query_type=>'TABLE'
,p_query_table=>'OCW_RUN_RESULTS'
,p_include_rowid_column=>false
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attribute_01=>'Detection: &OUTPUT_IN_SCREEN.'
,p_attribute_02=>'Out of &TOTAL_SECONDS_VIDEO_ANALYZED. seconds the person was visible &SECONDS_IN_SCREEN. seconds in the video.'
,p_attribute_03=>'Transcription: &TRANSCRIPTION.'
,p_attribute_05=>'N'
,p_attribute_06=>'N'
,p_attribute_23=>'Y'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19327140102175530)
,p_name=>'JOB_RUN_OCID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'JOB_RUN_OCID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19327287071175531)
,p_name=>'TYPE_OF_ANALYSIS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TYPE_OF_ANALYSIS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19327408054175532)
,p_name=>'OUTPUT_IN_SCREEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OUTPUT_IN_SCREEN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19327444443175533)
,p_name=>'SECONDS_IN_SCREEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SECONDS_IN_SCREEN'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19327570399175534)
,p_name=>'TOTAL_SECONDS_VIDEO_ANALYZED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_SECONDS_VIDEO_ANALYZED'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19327614501175535)
,p_name=>'TRANSCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TRANSCRIPTION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19327768238175536)
,p_name=>'KEY_PHRASES_STRING'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'KEY_PHRASES_STRING'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19327909979175537)
,p_name=>'SENTIMENT_RESULT_STRING'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SENTIMENT_RESULT_STRING'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19327993899175538)
,p_name=>'NEG_ASPECTS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NEG_ASPECTS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19328085656175539)
,p_name=>'NON_OFFENSIVE_INT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NON_OFFENSIVE_INT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>100
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19328204511175540)
,p_name=>'OFFENSIVE_INT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OFFENSIVE_INT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>110
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(20543421237328491)
,p_name=>'NON_HATE_INT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NON_HATE_INT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>120
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(20543565076328492)
,p_name=>'HATE_INT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HATE_INT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>130
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20543726534328494)
,p_plug_name=>'Hate Indicators'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(32832328392424535)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_query_type=>'TABLE'
,p_query_table=>'OCW_RUN_RESULTS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_landmark_type=>'region'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(20543818450328495)
,p_region_id=>wwv_flow_imp.id(20543726534328494)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(20543976104328496)
,p_chart_id=>wwv_flow_imp.id(20543818450328495)
,p_seq=>10
,p_name=>'Hate'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select JOB_RUN_OCID,',
'       TYPE_OF_ANALYSIS,',
'       OUTPUT_IN_SCREEN,',
'       SECONDS_IN_SCREEN,',
'       TOTAL_SECONDS_VIDEO_ANALYZED,',
'       TRANSCRIPTION,',
'       KEY_PHRASES_STRING,',
'       SENTIMENT_RESULT_STRING,',
'       NEG_ASPECTS,',
'       NON_OFFENSIVE_INT,',
'       OFFENSIVE_INT,',
'       NON_HATE_INT,',
'       (HATE_INT/100.00) HATE_PCT,',
'       (select ''Hate'' from dual) LABEL',
'  from OCW_RUN_RESULTS',
'--where JOB_RUN_OCID = :JOBID',
''))
,p_ajax_items_to_submit=>'JOBID'
,p_items_value_column_name=>'HATE_PCT'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(20544020055328497)
,p_chart_id=>wwv_flow_imp.id(20543818450328495)
,p_seq=>20
,p_name=>'Non Hate'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select JOB_RUN_OCID,',
'       TYPE_OF_ANALYSIS,',
'       OUTPUT_IN_SCREEN,',
'       SECONDS_IN_SCREEN,',
'       TOTAL_SECONDS_VIDEO_ANALYZED,',
'       TRANSCRIPTION,',
'       KEY_PHRASES_STRING,',
'       SENTIMENT_RESULT_STRING,',
'       NEG_ASPECTS,',
'       NON_OFFENSIVE_INT,',
'       OFFENSIVE_INT,',
'       (NON_HATE_INT/100.00) NON_HATE_PCT,',
'       (HATE_INT/100.00) HATE_PCT,',
'       (select ''Non Hate'' from dual) LABEL',
'  from OCW_RUN_RESULTS',
'--where JOB_RUN_OCID = :JOBID',
''))
,p_ajax_items_to_submit=>'JOBID'
,p_items_value_column_name=>'NON_HATE_PCT'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19326604026175524)
,p_name=>'JOBID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
