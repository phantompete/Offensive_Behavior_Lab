prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>7487498804536870
,p_default_application_id=>100
,p_default_id_offset=>7489314402657690
,p_default_owner=>'MLTD_USERA01'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Data Science Application'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var myInterval; //Stores the interval variable',
'',
'function fn_click_trigger()',
'{',
'   myInterval = setInterval(fn_click, 5000); //Refresh every 5 seconds',
'   apex.item(''ANALYZE'').hide();',
'}',
'',
'function fn_click_stop()',
'{',
'    clearInterval(myInterval);',
'}',
'',
'function fn_click()',
'{',
'    // Call Ajax process to execute some PL/SQL code',
'    apex.server.process (''GetStatus'' //PL/SQL process name',
'    ,{x01: $v(''JOBRUN_RESPONSE'')}',
'    ,{ dataType : ''json''',
'    //, async : false',
'    , success : function(pData)',
'         {            ',
'             //Store the PL/SQL result in a Page item',
'             apex.item("LIFECYCLESTATE").setValue(pData.lifeState);',
'             apex.item("LIFECYCLEDETAILS").setValue(pData.lifeStatus);',
'         }',
'    }',
'    ).done( function(pData)',
'        {',
'            // Do the post processing here, next set of code post PL/SQL call',
'            if(pData.lifeState == "SUCCEEDED") {',
'                 fn_click_stop();',
'                 apex.submit(''STATUS'');',
'                 apex.item(''ANALYZE'').show();',
'            }',
'',
'            if(pData.lifeState == "FAILED") {',
'                 fn_click_stop();',
'                 apex.item(''ANALYZE'').show();',
'            }',
'        }',
'    );',
'}',
'',
'    ',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'MLTD_USERA01'
,p_last_upd_yyyymmddhh24miss=>'20230829103758'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33090843857424854)
,p_plug_name=>'Data Science Application'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured t-HeroRegion--centered'
,p_plug_template=>wwv_flow_imp.id(32881703290424568)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20544272395328499)
,p_plug_name=>'Video Preview'
,p_region_name=>'PREVIEW'
,p_parent_plug_id=>wwv_flow_imp.id(33090843857424854)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(32897497259424576)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_URL'
,p_plug_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_plug_display_when_condition=>'VIDEO_URL'
,p_attribute_01=>'&VIDEO_URL.'
,p_attribute_02=>'IFRAME'
,p_attribute_03=>'allowfullscreen width="100%" height="560"'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32192334739177599)
,p_plug_name=>'Container'
,p_parent_plug_id=>wwv_flow_imp.id(33090843857424854)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(32897497259424576)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32192771234177603)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(32192334739177599)
,p_button_name=>'Analyze'
,p_button_static_id=>'ANALYZE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32970706775424636)
,p_button_image_alt=>'Analyze'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32192797804177604)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(32192334739177599)
,p_button_name=>'Status'
,p_button_static_id=>'STATUS'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32970706775424636)
,p_button_image_alt=>'Status'
,p_button_redirect_url=>'javascript:fn_click_trigger();'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(20544134676328498)
,p_branch_name=>'ShowResults'
,p_branch_action=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::JOBID:&JOBRUN_RESPONSE.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'LIFECYCLESTATE'
,p_branch_condition_text=>'SUCCEEDED'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32192468457177600)
,p_name=>'VIDEO_URL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(32192334739177599)
,p_prompt=>'Video Url'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(32968272305424632)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32192512139177601)
,p_name=>'ALGORITHM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(32192334739177599)
,p_prompt=>'Analysis Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ALGORITHM_TYPES'
,p_lov=>'.'||wwv_flow_imp.id(33166615439734105)||'.'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(32968272305424632)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32192646343177602)
,p_name=>'PICTURE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(32192334739177599)
,p_prompt=>'Picture'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_display_when=>'ALGORITHM'
,p_display_when2=>'video_only:both'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>wwv_flow_imp.id(32968272305424632)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'.jpg'
,p_attribute_12=>'DROPZONE_INLINE'
,p_attribute_13=>'Upload Profile Picture'
,p_attribute_14=>'The image should display a selfie of a single person.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32193439269177610)
,p_name=>'JOBRUN_RESPONSE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(32192334739177599)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32193491829177611)
,p_name=>'LIFECYCLESTATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(32192334739177599)
,p_prompt=>'Lifecycle State'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(32968272305424632)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32193668343177612)
,p_name=>'LIFECYCLEDETAILS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(32192334739177599)
,p_prompt=>'Lifecycle Details'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(32968272305424632)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20544347736328500)
,p_name=>'YouTube_Video'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'VIDEO_URL'
,p_bind_type=>'one'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20544471662328501)
,p_event_id=>wwv_flow_imp.id(20544347736328500)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var video=apex.items.VIDEO_URL.value;',
'video = video.replace(''/shorts/'', ''/embed/'');',
'video = video +''?autoplay=1&mute=1'';',
'apex.item("VIDEO_URL").setValue(video);',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20544527650328502)
,p_event_id=>wwv_flow_imp.id(20544347736328500)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20544670165328503)
,p_event_id=>wwv_flow_imp.id(20544347736328500)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(20544272395328499)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32192952605177605)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'JobProcess'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(32192771234177603)
,p_internal_uid=>11835271611517814
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32194845804177624)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GetStatus'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_params apex_exec.t_parameters;',
'    j apex_json.t_values;',
'    lifecyclestate varchar2(50);',
'    lifecyclestatus varchar2(250);',
'BEGIN',
'    apex_json.parse(j, :JOBRUN_RESPONSE);',
'    apex_exec.add_parameter( l_params, ''id'', apex_json.get_varchar2(p_path=>''id'',p0=> 3,p_values=>j) );',
'    apex_exec.add_parameter( l_params, ''jobId'',apex_json.get_varchar2(p_path=>''jobId'',p0=> 3,p_values=>j) );',
'    apex_exec.add_parameter( l_params, ''compartmentId'',apex_json.get_varchar2(p_path=>''compartmentId'',p0=> 3,p_values=>j) );',
'    apex_exec.add_parameter( l_params, ''projectId'',apex_json.get_varchar2(p_path=>''projectId'',p0=> 3,p_values=>j) );',
'',
'    apex_exec.execute_rest_source(',
'        p_static_id        => ''listjobruns'', --Get this static ID from the REST Data Source',
'        p_operation        => ''GET'',',
'        p_parameters       => l_params );',
'',
'     apex_json.parse(j, apex_exec.get_parameter_clob(l_params,''Response''));',
'     apex_json.open_object;',
'  ',
'     lifecyclestate := apex_json.get_varchar2(p_path=>''[%d].lifecycleState'',p0 => 1,p_values=>j);',
'     lifecyclestatus := apex_json.get_varchar2(p_path=>''[%d].lifecycleDetails'',p0 => 1,p_values=>j);',
'     ',
'     apex_json.write( p_name  => ''lifeState'', p_value => lifecyclestate);',
'     apex_json.write( p_name  => ''lifeStatus'', p_value => lifecyclestatus);',
'',
'     apex_json.close_object;',
'     :LIFECYCLESTATE := lifecyclestate; --Persist update of status.',
'',
'     IF (lifecyclestate = ''SUCCEEDED'') THEN',
'         :JOBRUN_RESPONSE := apex_json.get_varchar2(p_path=>''id'',p0=> 3,p_values=>j);',
'     END IF;',
'',
'END;',
'',
'    '))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'JOBRUN_RESPONSE'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>11837164810517833
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32193079993177606)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(32192952605177605)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UploadPictureSQL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request_url varchar(32000);',
'    l_content_length number;',
'    l_response clob;',
'    upload_failed_exception exception;',
'    l_request_object blob;',
'    l_request_filename varchar2(500);',
'    begin',
'        select blob_content, filename into l_request_object, l_request_filename from apex_application_temp_files where name = :PICTURE;',
'        --Update with your Object Storage, Namespace, Bucket.',
'        l_request_url := ''https://objectstorage.eu-frankfurt-1.oraclecloud.com/n/oractdemeabdmanalytics/b/ocw_root/o/''|| ''&APP_USER.'' || ''/'' || apex_util.url_encode(l_request_filename);        ',
'l_response := apex_web_service.make_rest_request(',
'            p_url => l_request_url,',
'            p_http_method => ''PUT'',',
'            p_body_blob => l_request_object,',
'            p_credential_static_id => ''OCI_API'' --Update with your Web Credentials',
'        );end;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'PICTURE'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>11835398999517815
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32193138254177607)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(32192952605177605)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'CreateJobRun'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(33147158453495424)
,p_web_src_operation_id=>wwv_flow_imp.id(33147368736495425)
,p_attribute_01=>'WEB_SOURCE'
,p_internal_uid=>11835457260517816
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(32193745012177613)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(33150434016564427)
,p_page_process_id=>wwv_flow_imp.id(32193138254177607)
,p_value_type=>'ITEM'
,p_value=>'ALGORITHM'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(32193798429177614)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(33151907624564428)
,p_page_process_id=>wwv_flow_imp.id(32193138254177607)
,p_value_type=>'STATIC'
,p_value=>'ocw_root'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(32193900882177615)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(33151389501564428)
,p_page_process_id=>wwv_flow_imp.id(32193138254177607)
,p_value_type=>'STATIC'
,p_value=>'oractdemeabdmanalytics'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(32193988458177616)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(33148900106564427)
,p_page_process_id=>wwv_flow_imp.id(32193138254177607)
,p_value_type=>'STATIC'
,p_value=>'ocid1.compartment.oc1..aaaaaaaaicxnkb6iumnvekw3xugguxoznng54itwzy5ohvv2x2nczttvusla'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(32194097841177617)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(33149895179564427)
,p_page_process_id=>wwv_flow_imp.id(32193138254177607)
,p_value_type=>'STATIC'
,p_value=>'MyNewJobatOCW'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(32194213410177618)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(33149432741564427)
,p_page_process_id=>wwv_flow_imp.id(32193138254177607)
,p_value_type=>'STATIC'
,p_value=>'Enter your job OCID here. '
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(32194352084177619)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(33148458439564426)
,p_page_process_id=>wwv_flow_imp.id(32193138254177607)
,p_value_type=>'STATIC'
,p_value=>'Enter your project ID here.'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(32194472832177620)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(33152923611580761)
,p_page_process_id=>wwv_flow_imp.id(32193138254177607)
,p_value_type=>'ITEM'
,p_value=>'JOBRUN_RESPONSE'
,p_ignore_output=>false
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(32194541778177621)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(33152444729564428)
,p_page_process_id=>wwv_flow_imp.id(32193138254177607)
,p_value_type=>'SQL_QUERY'
,p_value=>'select UPPER(:APP_USER) from dual;'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(32194635098177622)
,p_page_id=>1
,p_web_src_param_id=>wwv_flow_imp.id(33150892530564428)
,p_page_process_id=>wwv_flow_imp.id(32193138254177607)
,p_value_type=>'ITEM'
,p_value=>'VIDEO_URL'
);
wwv_flow_imp.component_end;
end;
/
