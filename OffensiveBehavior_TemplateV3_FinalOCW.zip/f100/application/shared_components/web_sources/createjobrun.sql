prompt --application/shared_components/web_sources/createjobrun
begin
--   Manifest
--     WEB SOURCE: CreateJobRun
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>7487498804536870
,p_default_application_id=>100
,p_default_id_offset=>7489314402657690
,p_default_owner=>'MLTD_USERA01'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(33147158453495424)
,p_name=>'CreateJobRun'
,p_static_id=>'createjobrun'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(33146323577495416)
,p_remote_server_id=>wwv_flow_imp.id(20277797951493312)
,p_url_path_prefix=>'/20190101'
,p_credential_id=>wwv_flow_imp.id(20365362863790993)
,p_attribute_05=>'1'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(33147368736495425)
,p_web_src_module_id=>wwv_flow_imp.id(33147158453495424)
,p_operation=>'POST'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'/jobRuns'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'    "projectId": "#projectid#",',
'    "compartmentId": "#compartmentid#",',
'    "jobId": "#jobid#",',
'    "definedTags": {},',
'    "displayName": "#displayName#",',
'    "freeformTags": {},',
'    "jobConfigurationOverrideDetails": {',
'        "jobType": "DEFAULT",',
'        "environmentVariables": {',
'            "TYPE_OF_ANALYSIS": "#ANALYSIS_TYPE#",  ',
'            "YOUTUBE_URL": "#YOUTUBE_URL#",',
'            "NAMESPACE_NAME" : "#BUCKET_NAMESPACE#",',
'            "MAIN_BUCKET_NAME": "#BUCKET_NAME#", ',
'            "SCHEMA_NAME": "#SCHEMA_NAME#"}',
'        }',
'    }',
'}'))
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(33148458439564426)
,p_web_src_module_id=>wwv_flow_imp.id(33147158453495424)
,p_web_src_operation_id=>wwv_flow_imp.id(33147368736495425)
,p_name=>'projectid'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(33148900106564427)
,p_web_src_module_id=>wwv_flow_imp.id(33147158453495424)
,p_web_src_operation_id=>wwv_flow_imp.id(33147368736495425)
,p_name=>'compartmentid'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(33149432741564427)
,p_web_src_module_id=>wwv_flow_imp.id(33147158453495424)
,p_web_src_operation_id=>wwv_flow_imp.id(33147368736495425)
,p_name=>'jobid'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(33149895179564427)
,p_web_src_module_id=>wwv_flow_imp.id(33147158453495424)
,p_web_src_operation_id=>wwv_flow_imp.id(33147368736495425)
,p_name=>'displayName'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(33150434016564427)
,p_web_src_module_id=>wwv_flow_imp.id(33147158453495424)
,p_web_src_operation_id=>wwv_flow_imp.id(33147368736495425)
,p_name=>'ANALYSIS_TYPE'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(33150892530564428)
,p_web_src_module_id=>wwv_flow_imp.id(33147158453495424)
,p_web_src_operation_id=>wwv_flow_imp.id(33147368736495425)
,p_name=>'YOUTUBE_URL'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(33151389501564428)
,p_web_src_module_id=>wwv_flow_imp.id(33147158453495424)
,p_web_src_operation_id=>wwv_flow_imp.id(33147368736495425)
,p_name=>'BUCKET_NAMESPACE'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(33151907624564428)
,p_web_src_module_id=>wwv_flow_imp.id(33147158453495424)
,p_web_src_operation_id=>wwv_flow_imp.id(33147368736495425)
,p_name=>'BUCKET_NAME'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(33152444729564428)
,p_web_src_module_id=>wwv_flow_imp.id(33147158453495424)
,p_web_src_operation_id=>wwv_flow_imp.id(33147368736495425)
,p_name=>'SCHEMA_NAME'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(33152923611580761)
,p_web_src_module_id=>wwv_flow_imp.id(33147158453495424)
,p_web_src_operation_id=>wwv_flow_imp.id(33147368736495425)
,p_name=>'Response'
,p_param_type=>'BODY'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(33153286422590502)
,p_web_src_module_id=>wwv_flow_imp.id(33147158453495424)
,p_web_src_operation_id=>wwv_flow_imp.id(33147368736495425)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp.component_end;
end;
/
