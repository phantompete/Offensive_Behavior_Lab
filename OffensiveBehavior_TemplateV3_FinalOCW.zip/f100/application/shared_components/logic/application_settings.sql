prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>7487498804536870
,p_default_application_id=>100
,p_default_id_offset=>7489314402657690
,p_default_owner=>'MLTD_USERA01'
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(33082593387424816)
,p_name=>'FEEDBACK_ATTACHMENTS_YN'
,p_value=>'Y'
,p_is_required=>'N'
,p_valid_values=>'Y, N'
,p_on_upgrade_keep_value=>true
,p_required_patch=>wwv_flow_imp.id(33081172362424810)
);
wwv_flow_imp.component_end;
end;
/
