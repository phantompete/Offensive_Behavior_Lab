prompt --application/shared_components/globalization/language
begin
--   Manifest
--     LANGUAGE MAP: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>7487498804536870
,p_default_application_id=>100
,p_default_id_offset=>7489314402657690
,p_default_owner=>'MLTD_USERA01'
);
null;
wwv_flow_imp.component_end;
end;
/
